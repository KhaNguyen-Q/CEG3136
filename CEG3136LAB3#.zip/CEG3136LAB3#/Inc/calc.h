/*
 * calc.h
 *
 *  Created on: Nov 3, 2025
 *      Author: knguy138
 */

#ifndef CALC_H_
#define CALC_H_

void Init_Calc(void);
void Task_Calc(void);

#endif /* CALC_H_ */
