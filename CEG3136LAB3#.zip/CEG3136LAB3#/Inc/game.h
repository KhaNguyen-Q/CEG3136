/*
 * game.h
 *
 *  Created on: Oct 20, 2025
 *      Author: bguer053
 */

#ifndef GAME_H_
#define GAME_H_

void Init_Game();
void Task_Game();



#endif /* GAME_H_ */
