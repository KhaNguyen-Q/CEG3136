/*
 * alarm.h
 *
 *  Created on: Sep 29, 2025
 *      Author: bguer053
 */

#ifndef ALARM_H_
#define ALARM_H_

void Init_Alarm();
void Task_Alarm();


#endif /* ALARM_H_ */
